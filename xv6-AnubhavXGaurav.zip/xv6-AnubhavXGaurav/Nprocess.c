#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char* argv[]){
	if(argc < 2){
		printf(0, "Parent process pid %d\n", getpid());
	}
	else{
		int n = atoi(argv[1]);
		int i;
		for(i = 1; i < n; i++){
			if(fork() == 0){
				printf(0, "Child process pid %d\n", getpid());
				exit();
			}
		}
		printf(0, "Parent process pid %d\n", getpid());
		for(i = 0; i < n; i++)
			wait();
	}
	exit();
}
